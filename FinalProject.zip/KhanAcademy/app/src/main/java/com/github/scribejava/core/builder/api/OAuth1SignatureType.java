package com.github.scribejava.core.builder.api;

public enum OAuth1SignatureType {

    Header,
    QueryString
}
