package com.example.shoppingcart.prevalent;

import com.example.shoppingcart.Model.Users;

public class prevalent {
    private static Users currentonlineUser;


}
