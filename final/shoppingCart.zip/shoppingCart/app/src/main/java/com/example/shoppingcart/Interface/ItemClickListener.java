package com.example.shoppingcart.Interface;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongCLick);
}
